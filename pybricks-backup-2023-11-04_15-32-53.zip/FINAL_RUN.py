from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase, GyroDriveBase
from pybricks.tools import wait, StopWatch
from FINAL_DATABASE import * # importing runs

hub = PrimeHub()

runs=["run1()","run2()","run3()","run4()", "run5()", "run6()"] # stores imported runs
hub.system.set_stop_button(Button.BLUETOOTH)
number=0 # run number
hub.display.text('0')
while True:
    
    if len(hub.buttons.pressed())>0: # checks amount of buttons pressed
        if hub.buttons.pressed()[0] == Button.RIGHT: # checks if number needs to be added to
            number+=1 # adds run
            if number==7: # resets at maximum number
                number=1
            hub.display.text(str(number),on=150) # displays run

    if len(hub.buttons.pressed())>0: # checks if a button is pressed
        if hub.buttons.pressed()[0] == Button.LEFT: # checks if number needs to be subtracted from
            number-=1 # subtracts run
            if number==0: # resets at minumum number
                number=1
            hub.display.text(str(number),on=150) # displays number

    if len(hub.buttons.pressed())>0: # checks if buttons are pressed
        if hub.buttons.pressed()[0] == Button.CENTER: # checks if things need to run
            eval(runs[number-1]) # runs the current run