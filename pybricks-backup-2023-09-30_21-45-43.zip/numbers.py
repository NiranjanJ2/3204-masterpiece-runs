from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

def write(number):
    if number==0:
        hub.display.animate(
            [
                [100,100,100,100,100],
                [100,0,0,0,100],
                [100,0,0,0,100],
                [100,0,0,0,100],
                [100,100,100,100,100]
            ], 1500
        )

write(0)

